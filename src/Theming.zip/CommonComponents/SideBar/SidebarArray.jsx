import ONE from './images/Ellipse 2.png'
import TWO from './images/Ellipse 3.png'
import THREE from './images/Ellipse 4.png'
import FOUR from './images/Ellipse 5.png'
import FIVE from './images/Ellipse 6.png'
import SIX from './images/Ellipse 7.png'
import SEVEN from './images/Ellipse 8.png'
import EIGHT from './images/Ellipse 9.png'



const SideBarArray = [
    {
        Img: ONE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
        to:'/'
    },
    {
        Img: TWO,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
        to:'/one'

    },
    {
        Img: THREE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
        to:'/two'

    },
    {
        Img: FOUR,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
        to:'/three'

    },
    {
        Img: FIVE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
        to:'/four'

    },
    {
        Img: SIX,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
        to:'/five'

    },
    {
        Img: SEVEN,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
        to:'/six'

    },
    {
        Img: EIGHT,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
        to:'/seven'

    },

]

export default SideBarArray
export const SideBarArray2 = [
  {
    text1: "Deals",
  },
  {
    text1: "Buy again",
  },
  {
    text1: "Lists",
  },
];

export const SidebarArray3 = [
  {
    title: "Recipes",
  },
  {
    title: "Produce",
  },
  {
    title: "Dairy & Eggs",
  },
  {
    title: "Beverages",
  },
  {
    title: "Meat & Seafood",
  },
  {
    title: "Snacks & Candy",
  },
  {
    title: "Frozen",
  },
  {
    title: "Bakery",
  },
  {
    title: "Deli",
  },
  {
    title: "Prepared Foods",
  },
  {
    title: "Alcohol",
  },
  {
    title: "Dry Goods & Pasta",
  },
  {
    title: "Condiments & Sauces",
  },
  {
    title: "Canned Goods & Soups",
  },
  {
    title: "Breakfast",
  },
  {
    title: "Household",
  },
  {
    title: "Baking Essentials",
  },
  {
    title: "Oils, Vinegars, & Spices",
  },
  {
    title: "Health Care",
  },
  {
    title: "Personal Care",
  },
  {
    title: "Kitchen Supplies",
  },
  {
    title: "Party & Gift Supplies",
  },
  {
    title: "Baby",
  },
  {
    title: "Pets",
  },
  {
    title: "Miscellaneous",
  },
  {
    title: "Office & Craft",
  },
  {
    title: "Ready Meals",
  },
  {
    title: "Recipes",
  },
  {
    title: "𝘖 Organics ®",
  },
  {
    title: "Open Nature ®",
  },
  {
    title: "Recipes",
  },
  {
    title: "Sales",
  },
];

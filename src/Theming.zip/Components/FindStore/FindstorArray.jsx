import Rectangle1 from './images/Rectangle1.png'
import Rectangle2 from './images/Rectangle2.png'
import Rectangle3 from './images/Rectangle3.png'
import Rectangle4 from './images/Rectangle4.png'
import Rectangle5 from './images/Rectangle5.png'

const FindStorArray = [
    {
        IMG: Rectangle1,
        title:"Home Hardware",
    },
    {
        IMG: Rectangle2,
        title:"Pets",
    },
    {
        IMG: Rectangle3,
        title:"Gourmet Gifts",
    },
    {
        IMG: Rectangle4,
        title:"Floral",
    },
    {
        IMG: Rectangle5,
        title:"Clothing",
    },
]

export default FindStorArray
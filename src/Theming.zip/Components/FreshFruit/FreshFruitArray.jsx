import IMG from "./images/Rectangle58.png";
import IMG1 from "./images/Rectangle59.png";
import IMG2 from "./images/Rectangle60.png";

const FreshArray = [
    {
        Img : IMG,
        title:"Organic Bananas $1.19 / lb",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG1,
        title:"Driscoll's Strawberries 16 oz Container",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG2,
        title:"Hass Avocado 7 count bag",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG,
        title:"Organic Bananas $1.19 / lb",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG1,
        title:"Driscoll's Strawberries 16 oz Container",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },
    {
        Img : IMG,
        title:"Organic Bananas $1.19 / lb",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG1,
        title:"Driscoll's Strawberries 16 oz Container",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG2,
        title:"Hass Avocado 7 count bag",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG,
        title:"Organic Bananas $1.19 / lb",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG1,
        title:"Driscoll's Strawberries 16 oz Container",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },

   
     
                                                            
]

export default FreshArray
import IMG from "./images/Rectangle58.png";
import IMG1 from "./images/Rectangle59.png";
import IMG2 from "./images/Rectangle60.png";

const FreshVegetableArray = [
    {
        Img : IMG,
        title:"Yellow Onion $2.29 / lb",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG1,
        title:"Broccoli Crown $3.49 / lb",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG2,
        title:"Green Bell Pepper",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG,
        title:"Yellow Onion $2.29 / lb",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG1,
        title:"Broccoli Crown $3.49 / lb",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },
    {
        Img : IMG,
        title:"Yellow Onion $2.29 / lb",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG1,
        title:"Broccoli Crown $3.49 / lb",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG2,
        title:"Green Bell Pepper",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG,
        title:"Yellow Onion $2.29 / lb",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG1,
        title:"Broccoli Crown $3.49 / lb",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },

   
     
                                                            
]

export default FreshVegetableArray
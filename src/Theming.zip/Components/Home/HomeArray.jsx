
import Img5 from './images/Rectangle1.png'
import Img6 from './images/Rectangle2.png'
import Img7 from './images/Rectangle3.png'
import Img8 from './images/Rectangle4.png'
import Img9 from './images/Rectangle5.png'
import Img10 from './images/Rectangle6.png'

 const AvatarImg = [
    
    {
        IMG:Img5
    },
    {
        IMG:Img6
    },
    {
        IMG:Img7
    },
    {
        IMG:Img8
    },
    {
        IMG:Img9
    },
    {
        IMG:Img10
    },

]

export default AvatarImg

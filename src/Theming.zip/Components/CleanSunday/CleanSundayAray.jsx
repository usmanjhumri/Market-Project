import IMG from "./images/Rectangle58.png";

const CleanSundayAray = [
    {
        Img : IMG,
        title:"Aveeno Eczema Therapy Daily Soothing Body Cream, Steroid-Free, 7.3 oz",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG,
        title:"Aveeno Eczema Therapy Daily Soothing Body Cream, Steroid-Free, 7.3 oz",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG,
        title:"Aveeno Eczema Therapy Daily Soothing Body Cream, Steroid-Free, 7.3 oz",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG,
        title:"Aveeno Eczema Therapy Daily Soothing Body Cream, Steroid-Free, 7.3 oz",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG,
        title:"Aveeno Eczema Therapy Daily Soothing Body Cream, Steroid-Free, 7.3 oz",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },
    {
        Img : IMG,
        title:"Aveeno Eczema Therapy Daily Soothing Body Cream, Steroid-Free, 7.3 oz",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG,
        title:"Aveeno Eczema Therapy Daily Soothing Body Cream, Steroid-Free, 7.3 oz",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG,
        title:"Aveeno Eczema Therapy Daily Soothing Body Cream, Steroid-Free, 7.3 oz",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG,
        title:"Aveeno Eczema Therapy Daily Soothing Body Cream, Steroid-Free, 7.3 oz",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },  
    {
        Img : IMG,
        title:"Aveeno Eczema Therapy Daily Soothing Body Cream, Steroid-Free, 7.3 oz",
        rating:"12 reveiws",
        price:"0.01ETH / $18.39",
    },
   
     
                                                            
]

export default CleanSundayAray
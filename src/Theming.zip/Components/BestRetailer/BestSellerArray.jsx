import ONE from './images/Ellipse 2.png'




const BestRetailerArray = [
    {
        Img: ONE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
    },
    {
        Img: ONE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
    },
    {
        Img: ONE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
    },
    {
        Img: ONE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
    },
    {
        Img: ONE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
    },
    {
        Img: ONE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
    },
    {
        Img: ONE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
    },
    {
        Img: ONE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
    },
    
]

export default BestRetailerArray
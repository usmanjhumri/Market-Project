import IMG from "./images/Rectangle58.png";
import IMG1 from "./images/Rectangle59.png";

const SnacksArray = [
  {
    Img: IMG,
    title: "Orville Redenbacher's Movie Theater Butter Classic Bag 19.74 oz",
    rating: "12 reveiws",
    price: "0.01ETH / $18.39",
  },
  {
    Img: IMG1,
    title: "Pepperidge Farm® Goldfish® Cheddar Crackers 6.6 oz",
    rating: "12 reveiws",
    price: "0.01ETH / $18.39",
  },
  {
    Img: IMG,
    title: "Orville Redenbacher's Movie Theater Butter Classic Bag 19.74 oz",
    rating: "12 reveiws",
    price: "0.01ETH / $18.39",
  },
  {
    Img: IMG1,
    title: "Pepperidge Farm® Goldfish® Cheddar Crackers 6.6 oz",
    rating: "12 reveiws",
    price: "0.01ETH / $18.39",
  },
  {
    Img: IMG,
    title: "Orville Redenbacher's Movie Theater Butter Classic Bag 19.74 oz",
    rating: "12 reveiws",
    price: "0.01ETH / $18.39",
  },
  {
    Img: IMG,
    title: "Orville Redenbacher's Movie Theater Butter Classic Bag 19.74 oz",
    rating: "12 reveiws",
    price: "0.01ETH / $18.39",
  },
  {
    Img: IMG1,
    title: "Pepperidge Farm® Goldfish® Cheddar Crackers 6.6 oz",
    rating: "12 reveiws",
    price: "0.01ETH / $18.39",
  },
  {
    Img: IMG,
    title: "Orville Redenbacher's Movie Theater Butter Classic Bag 19.74 oz",
    rating: "12 reveiws",
    price: "0.01ETH / $18.39",
  },
  {
    Img: IMG1,
    title: "Pepperidge Farm® Goldfish® Cheddar Crackers 6.6 oz",
    rating: "12 reveiws",
    price: "0.01ETH / $18.39",
  },
  {
    Img: IMG,
    title: "Orville Redenbacher's Movie Theater Butter Classic Bag 19.74 oz",
    rating: "12 reveiws",
    price: "0.01ETH / $18.39",
  },
];

export default SnacksArray;

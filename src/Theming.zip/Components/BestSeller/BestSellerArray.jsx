import ONE from './images/Ellipse 2.png'




const BestSellerArray = [
    {
        Img: ONE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
    },
    {
        Img: ONE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
    },
    {
        Img: ONE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
    },
    {
        Img: ONE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
    },
    {
        Img: ONE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
    },
    {
        Img: ONE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
    },
    {
        Img: ONE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
    },
    {
        Img: ONE,
        text1:" BevMo!",
        text2:"Spirits   win   bear",
        text3:"Delivery",
    },
    
]

export default BestSellerArray